import { render } from "solid-js/web";
import { ThemeProvider } from 'solid-styled-components';
import App from './containers/App';
import { themes } from './utils/themeConfig';
import './globalStyles';

declare module "solid-js" {
  namespace JSX {
    interface Actions {
      draggable: boolean;
      model: [() => any, (v: any) => any];
    }
  }
}

render(
  () => (
    <ThemeProvider theme={themes.default}>
      <App />
    </ThemeProvider>
  ),
  document.getElementById('root') as any
);
