import { styled } from "solid-styled-components";

const Wrapper = styled("div")`
  table {
    width: 100%;
    border-collapse: collapse;

    tbody td,
    thead th {
      color: ${({ theme }: any) => theme.colors.primaryText};
      font-style: normal;
      font-weight: 600;
      font-size: 15px;
      line-height: 16px;
      text-align: left;
      padding-top: 10px;
      padding-bottom: 10px;
      & > input {
        cursor: pointer;
      }
    }

    tbody td {
      font-weight: normal;
      font-size: 15px;
      line-height: 16px;

      &:last-child {
        cursor: pointer;
      }
    }

    tbody tr,
    tbody tr td {
      border: none;
      &:hover {
        border: rgba(0, 0, 0, 0.15);
        background-color: "#fcfcfc";
      }
    }

    tbody tr {
      border: 1px solid transparent;
      
      &.active {
        border: 1px solid rgba(0,0,0,0.1);
        background: ${({ theme }) => theme.colors.grey};
      }
    }
  }

  .ellipsis {
    height: 4px;
    width: 4px;
    background: #555;
    margin: 5px auto;
    border-radius: 50%;
  }

  .sort-icon {
    color: ${({ theme }) => theme.colors.inActive};
    font-size: 8px;
    padding-left: 10px;
    display: flex;
    flex-direction: column;
    
    span {
      line-height: 1.2;
      display: block;
    }

    .active {
      color: ${({ theme }) => theme.colors.primaryText}; 
    }
  }

  .th__sorter {
    display: flex;
    cursor: pointer;
  }
`;

export default Wrapper;
