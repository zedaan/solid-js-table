import { Component, Show } from 'solid-js';

interface ICellProps {
  column: any;
  row: any;
  isSelected: boolean;
  toggleRow: any;
}

const Cell: Component<ICellProps> = (props: any) => (
  <td>
    <Show
      when={props.column.cellRenderer}
      fallback={props.row[props.column.accessor]}
    >
      <props.column.cellRenderer
        isSelected={props.isSelected}
        toggleRow={props.toggleRow}
      />
    </Show>
  </td>
);

export default Cell;
