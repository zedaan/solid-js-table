import { Component, Show } from 'solid-js';
import { renderHeaderIcon } from './sortHeaderIcon';

interface IHeaderCellProps {
  column: any;
  anySelected: any;
  toggleAll: any;
  onClick?: any;
  sortDirection: any;
  columnID: any;
}

const HeaderCell: Component<IHeaderCellProps> = (props: any) => (
  <th colSpan={props.column.colSpan} onClick={props?.onClick ?? null}>
    <div className={`${props.column.sort ? 'th__sorter' : ''}`} >
      <Show when={props.column.render} fallback={props.column.header}>
        <props.column.render
          anySelected={props.anySelected}
          toggleAll={props.toggleAll}
        />
      </Show>
      <Show when={props.column.sort}>
        {renderHeaderIcon(props.sortDirection, props.columnID)}
      </Show>
    </div>
  </th>
);

export default HeaderCell;
