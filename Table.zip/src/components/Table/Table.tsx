import { createSignal, createSelector, createComputed, For, createEffect } from "solid-js";
import { HeaderCell, Row } from './components';
import { defaultSorter, onSortHandler } from './components/helpers';
import Wrapper from "./styles";

const Table = (props: any) => {
  const [selected, setSelected] = createSignal(new Set(), false),
    toggleRow = (index: number) => (set: any) => {
      const list = new Set(selected());
      list[set ? "add" : "delete"](index);
      setSelected(list);
    },
    isSelected = createSelector(selected, (k, list) => list.has(k)),
    anySelected = () => selected().size,
    toggleAll = () => {
      const list = new Set(selected());
      if (list.size) list.clear();
      else props.data.forEach((_: any, i: number) => list.add(i));
      setSelected(list);
    },
    [getSortDirectionSignal, setSortDirection] = createSignal([null, null]),
    [getRows, setRows] = createSignal(props.rows),
    getSortDirection = (): any => {
      const sortDirection = getSortDirectionSignal()
      if (sortDirection !== undefined) {
        return sortDirection
      }
      else if (props?.sort?.defaultDirection !== undefined) {
        return props?.sort?.defaultDirection
      } else {
        return [null, null]
      }
    },
    rowSorter = props?.sort?.onSort ?? defaultSorter,
    sortRows = () => {
      const currentSortDirection = getSortDirection()
      if (
        currentSortDirection[0] === null &&
        props?.sort?.defaultDirection !== undefined
      ) {
        setRows(rowSorter({
          rows: getRows(), sortDirection: props?.sort?.defaultDirection
        }))
      }
      else if (currentSortDirection[0] !== null) {
        setRows(rowSorter({
          rows: getRows(), sortDirection: currentSortDirection 
        }))
      };
    },
    generateSortCallback = (e: any, columnID: any) => {
      setSortDirection(onSortHandler({ sortDirection: getSortDirection(), columnID, e }))
      sortRows();
    };

  createComputed(() => {
    setRows(props.data);
  })

  return (
    <Wrapper className={props.wrapperClass}>
      <table className={props.className}>
        <thead>
          <tr>
            <For each={props.headers}>
              {(column: any, index: any) => (
                <HeaderCell
                  column={column}
                  anySelected={anySelected}
                  toggleAll={toggleAll}
                  onClick={(e: any) => column.sort && generateSortCallback(e, column.accessor)}
                  sortDirection={getSortDirectionSignal()}
                  columnID={column.accessor}
                />
              )}
            </For>
          </tr>
        </thead>
        <tbody>
          <For each={getRows()}>
            {(row, index) => (
              <Row
                row={row}
                headers={props.headers}
                isSelected={isSelected(index())}
                toggleRow={toggleRow(index())}
              />
            )}
          </For>
        </tbody>
      </table>
    </Wrapper>
  );
};

export default Table;
