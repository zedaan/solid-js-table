import Table from "./Table";

const App: any = () => {
  const headers = [
    {
      header: "checkbox",
      render: (props: any) => (
        <input
          type="checkbox"
          checked={props.anySelected()}
          onInput={props.toggleAll}
        />
      ),
      cellRenderer: (props: any) => (
        <input
          type="checkbox"
          checked={props.isSelected}
          onInput={() => props.toggleRow(!props.isSelected)}
        />
      ),
    },
    {
      header: "Group",
      accessor: "name",
      sort: {
        defaultDirection: ['name', 'desc']
      },
    },
    {
      header: "Date",
      accessor: "date",
      sort: true,
    },
    {
      header: "Members",
      accessor: "members"
    },
    {
      header: "Posts",
      accessor: "posts"
    },
    {
      header: "CTR",
      accessor: "ctr"
    },
    {
      header: "",
      accessor: "action",
      cellRenderer: () => {
        return (
          <div>
            <div className="ellipsis"></div>
            <div className="ellipsis"></div>
            <div className="ellipsis"></div>
          </div>
        );
      }
    }
  ];

  const data = [
    {
      name: "Group 4",
      date: "Apr 31, 2021",
      members: "34,764",
      posts: "90K",
      ctr: "4.67%"
    },
    {
      name: "Group 1",
      date: "Apr 30, 2021",
      members: "30,545",
      posts: "100K",
      ctr: "5.67%"
    },
    
    {
      name: "Group 3",
      date: "Apr 30, 2021",
      members: "30,545",
      posts: "100K",
      ctr: "5.67%"
    },
    {
      name: "Group 2",
      date: "Apr 31, 2021",
      members: "34,764",
      posts: "90K",
      ctr: "4.67%"
    },
  ];

  return (
    <Table
      headers={headers}
      data={data}
      className="table"
      wrapperClass="wrapper--class"
    />
  );
};

export default App;
